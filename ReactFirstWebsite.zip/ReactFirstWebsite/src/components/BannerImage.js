import React from 'react';
import './master.css';
function BannerImage() {
  return(
    <div>
    <img className="banner" src="../images/Banner.jpg" alt="BannerImage" />
    </div>
  )
}
export default BannerImage;
